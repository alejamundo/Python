from django.contrib import admin

# Register your models here.
from .models import Descarga

admin.site.register(Descarga)