#Declare una lista llamada con el nombre de  temperatura, esta  lista debe recibir la temperatura 
# de diferentes ciudades en usuario debe ingresar por teclado el número total de temperaturas que 
# desea ingresar y  las diferentes temperaturas el algoritmo debe mostrar el promedio de 
# la temperatura (aproximado a 1 decimal, y cuantas temperaturas son mayores que el promedio)

import math
temperatura=[]
suma=0
count=0
n_tempe=int(input("Ingrese el número de temperaturas que desea ingresar: "))

for i in range(n_tempe):
    temperatura.append(float(input("Ingrese la temperatura "+str(i+1)+": ")))

#saco promedio con 1 deximal
for t in temperatura:
    suma+=t
promedio=suma/n_tempe

#identifico las temperaturas mayores al promedio
for t in temperatura:
    if t>promedio:
        count=count+1

print("La temperatura promedio es: "+str(round(promedio,1)))

if count>0:
    print("hay "+str(count)+" datos mayores al promedio")
else:
    print("No hay datos mayores al promedio")