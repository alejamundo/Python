#General el código para que un usuario ingrese por teclado N cantidad de números 
# de tipo int el sistema debe validar cual los números es el mayor y el menor




tamaño=int(input("Ingrese la cantidad de números que desea ingresar: "))
vector=[tamaño]
mayor=int (0)
menor=int(1000)

#lleno vector
for i in range(tamaño):
    vector.append(int(input("Ingrese un número: ")))

#ordeno vector
for v in vector:
    if v>mayor:
        mayor=v
    if v<menor:
        menor=v
        
print("El número mayor es: "+str(mayor))
print("El número menor es: "+str(menor))