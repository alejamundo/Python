#Realice la codificación que permita guardar un dato string (password) 
#en una variable, y posterior a esto realice la petición por consola para que ingrese una contraseña,
#  luego debe validar y mostrar por consola si el password ingresado por consola es el igual al almacenado 
# en la variable.
contraseña_almacenada="aleja123"
contraseña_ingresada=input("Ingrese la contraseña: ")

if contraseña_almacenada==contraseña_ingresada:
    print("La contraseña ingresada es correcta")
else:
    print("Contraseña incorrecta")