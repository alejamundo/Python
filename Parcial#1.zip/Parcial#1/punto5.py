#Realice un algoritmo que solicite un password ingresándolo por consola y la vuelva a solicitar 
# para confirmarla hasta que las dos contraseñas coincidan no se salga del ciclo

contraseña_almacena="aleja123"
coinciden=False

while coinciden==False:
    contraseña_ingresada=input("Ingrese la contraseña: ")
    if contraseña_almacena==contraseña_ingresada:
        coinciden=True
        print("Contraseña correcta: ")
    else:
        coinciden=False
        print("Contraseña incorrecta: ")
