vehicle  =  {

  "brand": "Chevrollet",
  "model": "Camaro",
  "year": 2000,
  "condition":"Second hand"
}
vehicle["price"]=10000 

print(vehicle)