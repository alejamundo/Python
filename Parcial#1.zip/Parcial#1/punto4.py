#Ejercicio 2 operadores aritméticos:
#Realice la codificación que solicite a una persona el peso en KG también que pida la estatura mts, 
# con estos datos se debe realizar el cálculo de IMC (índice de masa corporal)  guardarlo en una variable, 
# y luego mostrarlo por consola  de la siguiente manera (`Tu índice de masa corporal es <imc>) donde `<imc>` 
# es el índice de masa corporal calculado redondeado con dos decimales.

peso=float(input("ingrese tu peso: "))
estatura=float(input("ingrese tu estatura: "))
elevado=float(estatura*estatura)
imc=peso/elevado

print("Tu índice de masa corporal es "+str(round(imc,2)))