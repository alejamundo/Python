from django.contrib import admin
from .models import Reservas
# Register your models here.
admin.site.register(Reservas)
