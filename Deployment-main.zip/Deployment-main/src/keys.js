module.exports = {
    mongodb: {
      URI: 'mongodb+srv://juandavidrp21:hda7hG6Fib80NJop@cluster0.rsrswvi.mongodb.net/DB_Proyect'
    }
  };

