from django.contrib import admin
from .models import Resgistro


# Register your models here.
admin.site.register(Resgistro)