#importo la clase que usara la clase principla
from app.laboratorio import LaboratorioClinico
from app.ordenExamen import OrdenExamen
from app.examen import Examen
def main():
    # Crear una instancia de LaboratorioClinico 
    laboratorio = LaboratorioClinico()

    while True:
        print("\nMenu Principal:")
        print("\n¿Que deseas hacer?")
        print("1. Registrar Paciente")
        print("2. Consultar Paciente por Número de Documento")
        print("3. Registrar Órdenes de Examen y Exámenes")
        print("4. Generar Factura")
        print("5. Salir")

        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            laboratorio.registrarPaciente()
        elif opcion == "2":
            #pedimos el numero de documento y lo pasamos como paramero al metodo consulta
            numeroDocumento = input("Ingrese el número de documento del paciente a consultar: ")
            laboratorio.consultarPaciente(numeroDocumento)
        elif opcion =="3":
            # Solicitar datos para registrar órdenes de examen y exámenes
            numeroDocumento = input("Ingrese el número de documento del paciente para asociar la orden: ")
            # Llamar al método para registrar la orden y los exámenes asociados a un paciente
            laboratorio.registrarOrdenYExamenes(numeroDocumento)
        elif opcion == "4":
            #Solicito al numero de orden del que desea generar la factura
            numeroOrden = input("Ingrese el número de documento del paciente para Genrar la factura: ")
            laboratorio.generarFacturaSiEsParticular(numeroOrden)
        elif opcion == "5": 
            print("*******************************")
            print("Saliendo del programa.")
            #con break interrunpimos la ejecución
            break
        else:
            print("Opción no válida. Por favor, seleccione una opción válida.")


#indicando a python que esta es la clase principal
if __name__ == "__main__":
    main()