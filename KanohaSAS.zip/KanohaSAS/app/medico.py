
#importo clase padre
from app.persona import Persona

#Esta clase hereda de la clase persona ya que un medico es una persona
class Medico(Persona):
    def __init__(self, numeroDocumento, nombres, apellidos, tel, direccion, especialidad):
        # Llamamos al constructor de la clase padre (Persona)
        super().__init__(numeroDocumento, nombres, apellidos, tel)
        
        # Atributos específicos de Medico
        self._direccion = direccion
        self._especialidad = especialidad

    # Métodos para acceder a los atributos específicos de Medico
    def getDireccion(self):
        return self._direccion

    def getEspecialidad(self):
        return self._especialidad

    # Métodos para establecer los atributos específicos de Medico
    def setDireccion(self, direccion):
        self._direccion = direccion

    def setEspecialidad(self, especialidad):
        self._especialidad = especialidad
