#importo clases que usara esta clase
from app.paciente import Paciente
from app.ordenExamen import OrdenExamen
from app.examen import Examen
from app.entidadSalud import EntidadSalud

#Clase laboratorio endonde estan todos los metodos que usa el sistema
class LaboratorioClinico:
    def __init__(self):
        self.pacientes = {} # diccionario que almacenara los datos de los pacientes
        self.entidades_salud = {}  # Diccionario para almacenar entidades de salud


    #Metodo para registrar pacientes y validar si ya estan registrados
    def registrarPaciente(self):
        numeroDocumento = input("Ingrese el número de documento del paciente: ")
        #valido que la cedula no se encuentre registrada
        if numeroDocumento in self.pacientes:
            #si se quiere ingresar un paciente que ya esta registrado el sistema no se lo permite
            print("*******************************")
            print("El paciente ya está registrado.")
        else:
            #Pido los datos del paciente
            tipoDoc = input("Ingrese el tipo de documento del paciente: ")
            nombres = input("Ingrese los nombres del paciente: ")
            apellidos = input("Ingrese los apellidos del paciente: ")
            tel = input("Ingrese el teléfono del paciente: ")
            fechaNacimiento = input("Ingrese la fecha de nacimiento del paciente: ")
            pos = input("Ingrese el POS ( Planes Obligatorios de Salud) del paciente: ")
            cel = input("Ingrese el número de celular del paciente: ")
            email = input("Ingrese el correo electrónico del paciente: ")
            nombreContacto = input("Ingrese el nombre del contacto de emergencia: ")
            telContacto = input("Ingrese el teléfono del contacto de emergencia: ")

            #creo el paciente y le paso los datos para inicializar 
            paciente = Paciente(numeroDocumento, nombres, apellidos, tel, tipoDoc, fechaNacimiento, pos, cel, email, nombreContacto, telContacto)
            #asigno una clave al diccionario indicandole que la cedula es la clave de ese paciente(objeto)
            self.pacientes[numeroDocumento] = paciente
            print("*******************************")
            print("Paciente registrado con éxito.")

    #Metodo para consultar si un paciente ya esta registrado
    def consultarPaciente(self, numeroDocumento):
        #valido que en el diccionario este esa cedula 
        if numeroDocumento in self.pacientes:
            #almaceno el objeto de esa clave en la variable paciente
            paciente = self.pacientes[numeroDocumento]
            print("*******************************")
            print("Información del paciente:")
            print(paciente) #Muestro datos paciente 

            # Obtener las órdenes de examen asociadas al paciente
            ordenes_examen = paciente.getOrdenExamen()

            if ordenes_examen:
                print("*******************************")
                print("\nÓrdenes de Examen del paciente:")

                # Recorrer las órdenes de examen
                for orden in ordenes_examen:
                    #print(orden)
                    # Obtener los exámenes asociados a la orden
                    examenes = orden.obtenerExamenes()

                    if examenes:
                        print("*******************************")
                        print("\nExámenes realizados:")
                        # Mostrar los exámenes realizados con sus fechas de realización
                        for examen in examenes:
                            print(f'Tipo de Examen: {examen.getTipoExamen()}')
                            print(f'Fecha de Realización: {examen.getFechaRealizacion()}')
                            print("Observación:", examen.getObservacion())
                            print("")

                    else:
                        print("*******************************")
                        print("No se han realizado exámenes para esta orden.")
            else:
                print("*******************************")
                print("El paciente no tiene órdenes de examen registradas.")
        else:
            print("*******************************")
            print("Paciente no encontrado.")

    #Metodo para registrar ordenes y examenes asociados a la orden 
    def registrarOrdenYExamenes(self, numeroDocumento):
        # Verificar si el paciente existe
        if numeroDocumento in self.pacientes:
            paciente = self.pacientes[numeroDocumento]
            #pido datos de laorden si el paciente esta registrado
            orden = input("Ingrese el número de la orden de examen: ")
            fecha_solicitud = input("Ingrese la fecha de solicitud de la orden (AAAA-MM-DD): ")
            fecha_ingreso = input("Ingrese la fecha de ingreso al sistema de la orden (AAAA-MM-DD): ")
            medico = input("Ingrese el nombre del médico que emitió la orden: ")
            orden_medico = input("Ingrese el número de orden médica: ")

            # Crear una orden de examen con los datos ingresados instaciando la clase OrdenExamen
            orden_examen = OrdenExamen(orden, fecha_solicitud, fecha_ingreso, medico, orden_medico)


            # Solicitar datos de exámenes como pueden ser 1 o varios por orden se pide la cantidad
            # Para luego almacenarla en un array
            num_examenes = int(input("Ingrese la cantidad de exámenes a registrar: "))
            examenes = []

            #con este for pedimos los datos de los examenes
            for i in range(num_examenes):
                tipo_examen = input(f"Ingrese el tipo de examen {i + 1}: ")
                fecha_cita = input(f"Ingrese la fecha de cita del examen {i + 1} (AAAA-MM-DD): ")
                fecha_realizacion = input(f"Ingrese la fecha de realización del examen {i + 1} (AAAA-MM-DD): ")
                observacion = input(f"Ingrese observaciones para el examen {i + 1}: ")
                valor = input(f"Ingrese valor para el examen {i + 1}: ")

                #creamos los examenes usando la instacia Examen y agregamos el objeto examen al array
                examen = Examen(tipo_examen, fecha_cita, fecha_realizacion, observacion, valor)
                examenes.append(examen)
            # Asociar la orden de examen al paciente
            paciente.asociarOrdenExamen(orden_examen)

            # Asociar los exámenes a la orden de examen
            for examen in examenes:
                orden_examen.agregarExamen(examen)

            print("*******************************")
            print("Órdenes de examen y exámenes registrados con éxito.")
        else:
            print("*******************************")
            print("Paciente no encontrado, Recuerde que debe Registrar al pacientes antes de Asociar ordenes y examenes.")

    #Metodo para registrar factura si es particular o pertenece a entidad de salud
      # Método para generar factura o asociar entidad de salud
    def generarFacturaSiEsParticular(self, numeroDocumento):
        if numeroDocumento in self.pacientes:
            paciente = self.pacientes[numeroDocumento]
            # Preguntar si el paciente pertenece a una entidad de salud o es particular
            while True:
                es_entidad_salud = input("¿El paciente pertenece a una entidad de salud? (S/N): ").strip().lower()
                if es_entidad_salud == "s":
                    # Si pertenece a entidad de salud, solicitar datos de la entidad
                    nit_entidad = input("Ingrese el NIT de la entidad de salud: ")
                    telefono_entidad = input("Ingrese el teléfono de la entidad de salud: ")
                    celular_entidad = input("Ingrese el celular de la entidad de salud: ")
                    correo_entidad = input("Ingrese el correo de la entidad de salud: ")
                    nombre_persona_entidad = input("Ingrese el nombre de la persona de contacto en la entidad: ")
                    contacto_persona_entidad = input("Ingrese el contacto de la persona de contacto en la entidad: ")
                    tipo_entidad = input("Ingrese el tipo de entidad (contributivo/subsidiado/prepagada): ")

                    # Crear una instancia de EntidadPrestadoraDeServicios
                    entidad_salud = EntidadSalud(nit_entidad, telefono_entidad, celular_entidad, correo_entidad, nombre_persona_entidad, contacto_persona_entidad, tipo_entidad)

                    # Asociar al paciente con la entidad de salud
                    paciente.asociarEntidadSalud(entidad_salud)

                    # Almacenar la entidad de salud en el diccionario de entidades de salud con la clave como nit
                    self.entidades_salud[nit_entidad] = entidad_salud
                    break
                elif es_entidad_salud == "n":
                    # Si es particular, generar un detalle de factura
                    if any(paciente.getOrdenExamen()):
                        # Si el paciente tiene órdenes asociadas, calcula la factura
                        detalle_factura = []

                        # Agregar los datos del paciente al detalle de la factura
                        detalle_factura.append(f"Datos del Paciente:\n{str(paciente)}")

                        for orden in paciente.getOrdenExamen():
                            detalle_factura.append(f"Número de Orden: {orden.getOrden()}")

                            for examen in orden.obtenerExamenes():
                                detalle_factura.append(f"Examen: {examen.getTipoExamen()}, Valor: {examen.getValor()}")

                        # Calcular el total de la factura
                        #convertir a int el input valor 
                        valor=int(examen.getValor())
                        total_factura = sum(valor for orden in paciente.getOrdenExamen() for examen in orden.obtenerExamenes())

                        # Mostrar el detalle de la factura
                        print("\nDetalle de Factura para Paciente Particular:")
                        for detalle in detalle_factura:
                            print(detalle)
                        print(f"Total a Pagar: {total_factura}")
                    else:
                        print("*******************************")
                        print("El paciente no tiene órdenes de exámenes asociadas.")
                    break
                else:
                    print("*******************************")
                    print("Opción no válida, ingrese 'S' o 'N'.")
        else:
            print("*******************************")
            print("Paciente no encontrado.")