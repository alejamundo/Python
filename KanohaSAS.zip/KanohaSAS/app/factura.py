#clase que representa una factura
class Factura:
    #Metodo constructor que inicaliza los atributos de facturación
    def __init__(self, numeroFactura, valorPagar, informacionPaciente, fechaRealizacion):
        self._numeroFactura = numeroFactura
        self._valorPagar = valorPagar
        self._informacionPaciente = informacionPaciente
        self._fechaRealizacion = fechaRealizacion

    # Métodos getter para obtener los atributos
    def getNumeroFactura(self):
        return self._numeroFactura

    def getValorPagar(self):
        return self._valorPagar

    def getInformacionPaciente(self):
        return self._informacionPaciente

    def getFechaRealizacion(self):
        return self._fechaRealizacion

    # Métodos setter para establecer los atributos
    def setNumeroFactura(self, numeroFactura):
        self._numeroFactura = numeroFactura

    def setValorPagar(self, valorPagar):
        self._valorPagar = valorPagar

    def setInformacionPaciente(self, informacionPaciente):
        self._informacionPaciente = informacionPaciente

    def setFechaRealizacion(self, fechaRealizacion):
        self._fechaRealizacion = fechaRealizacion