#clase Persona
class Persona:
    #Metodo constructor que inicaliza las variables de la clase
    #el ._ significa que el atributo es privado
    def __init__(self, numeroDocumento, nombres, apellidos, tel):
        self._numeroDocumento = numeroDocumento
        self._nombres = nombres
        self._apellidos = apellidos
        self._tel = tel

    # Métodos para acceder a los atributos 
    def getNumeroDocumento(self):
        return self._numeroDocumento

    def getNombres(self):
        return self._nombres

    def getApellidos(self):
        return self._apellidos

    def getTel(self):
        return self._tel

    # Métodos para establecer los atributos 
    def setNumeroDocumento(self, numeroDocumento):
        self._numeroDocumento = numeroDocumento

    def setNombres(self, nombres):
        self._nombres = nombres

    def setApellidos(self, apellidos):
        self._apellidos = apellidos

    def setTel(self, tel):
        self._tel = tel
