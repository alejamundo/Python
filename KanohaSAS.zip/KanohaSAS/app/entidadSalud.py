#clase que represta las entidades de salud
class EntidadSalud:
    #Constructor que inicaliza las propiedades 
    def __init__(self, nit, telefono, celular, correo, nombrePersona, contactoPersona, tipoEntidad):
        self._nit = nit
        self._telefono = telefono
        self._celular = celular
        self._correo = correo
        self._nombrePersona = nombrePersona
        self._contactoPersona = contactoPersona
        self._tipoEntidad = tipoEntidad

    # Métodos getter para obtener los atributos
    def getNit(self):
        return self._nit

    def getTelefono(self):
        return self._telefono

    def getCelular(self):
        return self._celular

    def getCorreo(self):
        return self._correo

    def getNombrePersona(self):
        return self._nombrePersona

    def getContactoPersona(self):
        return self._contactoPersona

    def getTipoEntidad(self):
        return self._tipoEntidad

    # Métodos setter para establecer los atributos
    def setNit(self, nit):
        self._nit = nit

    def setTelefono(self, telefono):
        self._telefono = telefono

    def setCelular(self, celular):
        self._celular = celular

    def setCorreo(self, correo):
        self._correo = correo

    def setNombrePersona(self, nombrePersona):
        self._nombrePersona = nombrePersona

    def setContactoPersona(self, contactoPersona):
        self._contactoPersona = contactoPersona

    def setTipoEntidad(self, tipoEntidad):
        self._tipoEntidad = tipoEntidad

    # Método para mostrar la información de la entidad como string
    def __str__(self):
        return f"NIT: {self._nit}\nTeléfono: {self._telefono}\nCelular: {self._celular}\nCorreo: {self._correo}\n" \
               f"Nombre de Persona: {self._nombrePersona}\nContacto de Persona: {self._contactoPersona}\n" \
               f"Tipo de Entidad: {self._tipoEntidad}"