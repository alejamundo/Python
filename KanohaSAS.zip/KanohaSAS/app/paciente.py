
#importo clase padre
from app.persona import Persona

#Esta clase hereda de la clase persona ya que un paciente es una persona
class Paciente(Persona):
    def __init__(self, numeroDocumento, nombres, apellidos, tel, tipoDoc, fechaNacimiento, pos, cel, email, nombreContacto, telContacto):
        # Llamamos al constructor de la clase padre (Persona)
        super().__init__(numeroDocumento, nombres, apellidos, tel)
        
        # Atributos específicos de Paciente
        self._tipoDoc = tipoDoc
        self._fechaNacimiento = fechaNacimiento
        self._pos = pos
        self._cel = cel
        self._email = email
        self._nombreContacto = nombreContacto
        self._telContacto = telContacto
        self._ordenesExamen = []  # Lista para almacenar órdenes de examen del paciente
        self._entidadSAlud =None
       

    #Metodos utiles para ir almacenado a cada paciente las ordenes de examenes y los examenes
    def asociarOrdenExamen(self, ordenExamen):
        #agrego a la lista la orden de examen
        self._ordenesExamen.append(ordenExamen)

    def getOrdenExamen(self):
        return self._ordenesExamen
    
    def asociarEntidadSalud(self, entidad):
        self._entidadSAlud = entidad

    #Metodopara validar si el paciente tiene ordenes y por ende examenes realizados para posteriod¿r facturacion
    def tieneOrdenesAsociadas(self): 
        return bool(self._ordenesExamen)

    #Esto hace parte de la encapsulación
    # Métodos para acceder a los atributos específicos de Paciente
    def getTipoDoc(self):
        return self._tipoDoc

    def getFechaNacimiento(self,):
        return self._fechaNacimiento

    def getPos(self):
        return self._pos

    def getCel(self):
        return self._cel

    def getEmail(self):
        return self._email

    def getNombreContacto(self):
        return self._nombreContacto

    def getTelContacto(self):
        return self._telContacto

    # Métodos para establecer los atributos específicos de Paciente
    def setTipoDoc(self, tipoDoc):
        self._tipoDoc = tipoDoc

    def setFechaNacimiento(self, fechaNacimiento):
        self._fechaNacimiento = fechaNacimiento

    def setPos(self, pos):
        self._pos = pos

    def setCel(self, cel):
        self._cel = cel

    def setEmail(self, email):
        self._email = email

    def setNombreContacto(self, nombreContacto):
        self._nombreContacto = nombreContacto

    def setTelContacto(self, telContacto):
        self._telContacto = telContacto

    #Metodo sobreescrito de python para mostrar el objeto paciente como string
    def __str__(self):
        return f'Tipo de Documento: {self._tipoDoc} \nNúmero de Documento: {self._numeroDocumento}\nNombres: {self._nombres}\nApellidos: {self._apellidos}\nTeléfono: {self._tel}\nFecha de Nacimiento: {self._fechaNacimiento}\nPOS: {self._pos}\nCelular: {self._cel}\nEmail: {self._email}\nNombre de Contacto: {self._nombreContacto}\nTeléfono de Contacto: {self._telContacto}'