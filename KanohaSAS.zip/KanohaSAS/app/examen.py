#clase que representa un examen
class Examen:
    #constructor que inicializa los atributos de la clase
    def __init__(self, tipoExamen, fechaCita, fechaRealizacion, observacion,valor):
        #._ atributos privados
        self._tipoExamen = tipoExamen
        self._fechaCita = fechaCita
        self._fechaRealizacion = fechaRealizacion
        self._observacion = observacion
        self._valor = valor # Atributo para representar el valor del examen

    #Metodos getter y setter para acceder a los atributos y establecer sus valores 
    def getTipoExamen(self):
        return self._tipoExamen

    def getFechaCita(self):
        return self._fechaCita

    def getFechaRealizacion(self):
        return self._fechaRealizacion

    def getObservacion(self):
        return self._observacion
    
    def getValor(self):
        return self._valor 

    def setTipoExamen(self, tipoExamen):
        self._tipoExamen = tipoExamen

    def setFechaCita(self, fechaCita):
        self._fechaCita = fechaCita

    def setFechaRealizacion(self, fechaRealizacion):
        self._fechaRealizacion = fechaRealizacion

    def setObservacion(self, observacion):
        self._observacion = observacion

    def setValor(self, valor):
        self._valor = valor