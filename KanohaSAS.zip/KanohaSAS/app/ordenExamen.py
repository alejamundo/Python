 
#clase orden examen 
class OrdenExamen:
    def __init__(self, orden, fechaSolicitud, fechaIngreso, medico, ordenMedico):
        self._orden = orden
        self._fechaSolicitud = fechaSolicitud
        self._fechaIngreso = fechaIngreso
        self._medico = medico
        self._ordenMedico = ordenMedico
        self._examenes = []  # Lista para almacenar exámenes asociados a esta orden
        

    #Encapsulación de los atributos de la clase
    #metodos para manipular los examenes asociados a una orden 
    def agregarExamen(self, examen):
        self._examenes.append(examen)

    def obtenerExamenes(self):
        return self._examenes
    
    #gettern and setter
    def getOrden(self):
        return self._orden

    def getFechaSolicitud(self):
        return self._fechaSolicitud

    def getFechaIngreso(self):
        return self._fechaIngreso

    def getMedico(self):
        return self._medico

    def getOrdenMedico(self):
        return self._ordenMedico

    def setOrden(self, orden):
        self._orden = orden

    def setFechaSolicitud(self, fechaSolicitud):
        self._fechaSolicitud = fechaSolicitud

    def setFechaIngreso(self, fechaIngreso):
        self._fechaIngreso = fechaIngreso

    def setMedico(self, medico):
        self._medico = medico

    def setOrdenMedico(self, ordenMedico):
        self._ordenMedico = ordenMedico