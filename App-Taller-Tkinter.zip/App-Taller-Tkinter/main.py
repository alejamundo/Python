import tkinter as tk
from tkinter import ttk,messagebox

ventana=tk.Tk()
ventana.geometry('500x500')
ventana.title("Convertidor")

etiqueta1=tk.Label(ventana,text="Convertidor de grados") 
etiqueta1.grid(row=3,column=5,padx=10,pady=30)

   
def fare():
    num=numero.get()
    num_2=float(num)
    fare=(num_2*(9/5)+32)
    #rs=str(farenhet)
    result1=tk.Label(ventana,text=(f"Grados Farenheit: {round(fare,1)}") )
    result1.grid(row=9,column=0,padx=10)

def celci():
    num=numero.get()
    num_2=float(num)
    cel=((num_2-32)*(5/9))
    #rs=str(farenhet)
    result=tk.Label(ventana,text=(f"Grados Celsius: {round( cel,1)}") )
    result.grid(row=10,column=0,padx=10)

def calcular():

    num=numero.get()
    num_2=float(num)
    fare=(num_2*(9/5)+32)
    cel=((num_2-32)*(5/9))

    try:
        archivo=open("archivo.txt","w")
        archivo.write(f"La converción de grados celsius  ({num_2}) a grados farenheit es: {round(fare,1)}\n")
        archivo.write(f"La converción de grados Farenheit ({num_2}) a grados celcius es: {round(cel,1)}")
        result=tk.Label(ventana,text=(f"Datos exportados") )

        messagebox.showinfo("Datos exportados ","Datos exportados")

        result.grid(row=10,column=5,padx=50)
    except Exception as e:
        print("NO SE ENCONTRO EL ARCHIVO")

numero=ttk.Entry(ventana,width=20)
numero.grid(row=5,column=5)

btnfarenheit=ttk.Button(ventana,text="Convertir a Farenheit",command=fare)
btnfarenheit.grid(padx=50)

btncelcius=ttk.Button(ventana,text="Convertir a Celcius ",command=celci)
btncelcius.grid(padx=50)

btnExport=ttk.Button(ventana,text="Exportar",command=calcular)
btnExport.grid(padx=50,pady=30)

ventana.mainloop()

