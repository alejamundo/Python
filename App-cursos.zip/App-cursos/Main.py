from vistaInicio import Inscripcion

inicio=Inscripcion()
inicio.formulario()
