import tkinter as tk
from tkinter import ttk, messagebox
import json

class Inscripcion:
    # CONSTRUYO VENTANA INSCRIPCIÓN
    def __init__(self):
        self.windows = tk.Tk()
        # calculo coordendas para centrar la ventana
        self.ancho = 450
        self.alto = 300
        self.windows.geometry("{}x{}+{}+{}".format(self.ancho, self.alto, int(self.windows.winfo_screenwidth(
        ) / 2 - self.ancho/2), int(self.windows.winfo_screenheight()/2 - self.alto/2)))
        self.windows.title("Inscripción a cursos")

        # cambiar color a la ventana
        self.windows.configure(bg="#ECECEC")

    def formulario(self):
        # CONSTRUYO ETIQUETAS
        label0 = tk.Label(self.windows, text="Formulario de incripción a Cursos Tic", font=(
        "TkDefaultFont", 12, "bold"))
        label1 = tk.Label(self.windows, text="Nombres:")
        label2 = tk.Label(self.windows, text="Apellidos:")
        label3 = tk.Label(self.windows, text="Cursos Disponibles:")
        label4 = tk.Label(self.windows, text="Forma de pago:")
        label5 = tk.Label(self.windows)

        # CONSTRUYO ENTRADAS TXT
        nombre = tk.Entry(self.windows, width=30)
        apellido = tk.Entry(self.windows, width=30)

        opciones = ["Java", "Sprint Boot",
        "Javascript", "Node Js", "Python", "Django"]
        combo = ttk.Combobox(self.windows, values=opciones, width=22)
        opciones2 = ["Pagos a 6 Cuotas", "Pagos a 12 Cuotas", "Pago a 1 Cuota"]
        combo2 = ttk.Combobox(self.windows, values=opciones2, width=22)

        # CONSTRUYO BOTONES CON SUS RESPECTIVOS METODOS
        def AdminLogin():
            self.windows.withdraw()
            windows2 = tk.Toplevel()
            windows2.title("Ingreso Administrador")
            windows2.geometry("{}x{}+{}+{}".format(350, 200, int(windows2.winfo_screenwidth(
            ) / 2 - self.ancho/2), int(windows2.winfo_screenheight()/2 - self.alto/2)))

            tit = tk.Label(windows2, text="Inicio sección Administrador", font=(
            "TkDefaultFont", 12, "bold"))
            label11 = tk.Label(windows2, text="Usuario:")
            label22 = tk.Label(windows2, text="Contraseña:")
            label55 = tk.Label(windows2)

            usuario = tk.Entry(windows2, width=26)
            contraseña = tk.Entry(windows2, width=26)

            def validaIngreso():
                # Comprar datos correctos y mostrar matriculados
                if usuario.get() == "usuario" and contraseña.get() == "contraseña" or usuario.get()=="user" and contraseña.get()=="password":
                    #agregar usuarios a diccionario y a admin.txt
                    dicUsuarios={"usuario":"contraseña","user":"password"}
                    
                    try:
                      with open("admin.txt","a") as archivo:
                        #convierto dicionario a caddena
                        dicCadena=json.dumps(dicUsuarios)  
                        archivo.write(dicCadena)
                    except:
                      print('An exception occurred')
                    windows2.withdraw()
                    windows3 = tk.Toplevel()
                    windows3.title("Ingreso Administrador")
                    windows3.geometry("{}x{}+{}+{}".format(self.ancho, self.alto, int(windows3.winfo_screenwidth(
                    ) / 2 - self.ancho/2), int(windows2.winfo_screenheight()/2 - self.alto/2)))
                    
                    tit = tk.Label(windows3, text="Lista de Inscriptos a cursos", font=(
                        "TkDefaultFont", 10, "bold"))
                    tit.grid(row=0, column=0,padx=10)
                    
                    # traer datos y mostrar
                    text_area = tk.Text(windows3,width=60)
                    text_area.grid(row=2,column=0)
                    try:
                        
                        with open("Inscriptos.txt", "r") as archivo:
                            lineas=archivo.readlines()#almaceno en una lista
                            #mostrar en pantalla
                            for linea in lineas:
                                text_area.insert(tk.END,linea)
                            
                    except:
                        print('Archivo txt no encontrado')
                    
                else:
                    messagebox.showerror(
                        "Datos Erroneos", "Clave o Contraseña Invalidos")
                    usuario.delete("0", "end")
                    contraseña.delete("0", "end")
            ################################################################       
            botonlogin = tk.Button(windows2, text="Ingresar", font=(
            "TkDefaultFont", 10, "bold"), bg="#B8ACA3", command=validaIngreso)
            

            tit.grid(row=0, column=0, padx=70)
            label55.grid(row=0, column=0, sticky='w', padx=50, pady=20)
            label11.grid(row=1, column=0, sticky='w', padx=50, pady=3)
            label22.grid(row=2, column=0, sticky='w', padx=50, pady=3)

            usuario.grid(row=1, column=0)
            contraseña.grid(row=2, column=0)

            botonlogin.grid(row=5, column=0, pady=20)
           

        ######################################################################
        def inscripcion():
            if nombre.get() == "" or apellido.get() == "" or combo.get() == "" or combo2.get() == "":
                messagebox.showerror("Error", "Debe Llenar todos los campos")
                nombre.delete("0", "end")
                apellido.delete("0", "end")
                combo.delete("0", "end")
                combo2.delete("0", "end")
            else:
                #Ingresar datos a txt
                try:
                    with open("Inscriptos.txt", "a") as archivo:
                        archivo.write("\n"+nombre.get()+" "+apellido.get()+": "+combo.get()+"--> "+combo2.get()+".")
                except:
                    print('Archivo txt no encontrado')
                
                
                messagebox.showinfo("Datos correctos",nombre.get()+" Inscripción exitosa!")
                nombre.delete("0", "end")
                apellido.delete("0", "end")
                combo.delete("0", "end")
                combo2.delete("0", "end")
        ###########################################################################
        boton1 = tk.Button(self.windows, text="Inscribirse", font=(
            "TkDefaultFont", 10, "bold"), bg="#B8ACA3", command=inscripcion)

        boton2 = tk.Button(self.windows, text="Ingresar como Administrador", font=(
            "TkDefaultFont", 10, "bold"), bg="#B8ACA3", command=AdminLogin)

        # INSERTO COMPONENTES EN LA VENTANA
        label0.grid(row=0, column=0, padx=90)
        label5.grid(row=0, column=0, sticky='w', padx=50, pady=20)
        label1.grid(row=1, column=0, sticky='w', padx=50, pady=3)
        label2.grid(row=2, column=0, sticky='w', padx=50, pady=3)
        label3.grid(row=3, column=0, sticky='w', padx=50, pady=3)
        label4.grid(row=4, column=0, sticky='w', padx=50, pady=3)

        # coloco los txt
        nombre.grid(row=1, column=0)
        apellido.grid(row=2, column=0)

        # colocar combo
        combo.grid(row=3, column=0)
        combo2.grid(row=4, column=0)

        # coloco botones
        boton1.grid(row=5, column=0, pady=20)
        boton2.grid(row=6, column=0)

        # COORRO LA APP
        self.windows.mainloop()
